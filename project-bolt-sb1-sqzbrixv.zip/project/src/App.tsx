import React, { useState } from 'react';
import Header from './components/Header';
import Footer from './components/Footer';
import InputForm from './components/InputForm';
import RecommendationDisplay from './components/RecommendationDisplay';
import BudgetCalculator from './components/BudgetCalculator';
import BudgetTracker from './components/BudgetTracker';
import ItemRecommendations from './components/ItemRecommendations';
import { BudgetProvider } from './context/BudgetContext';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

function App() {
  const [recommendations, setRecommendations] = useState('');
  const [loading, setLoading] = useState(false);

  const handleRecommendationsReceived = (text: string) => {
    setRecommendations(text);
    
    // Show toast notification
    toast.success('Budget analysis complete!', {
      position: "top-right",
      autoClose: 3000,
      hideProgressBar: false,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: true,
    });
  };

  return (
    <BudgetProvider>
      <div className="pattern-bg text-neutral-800 min-h-screen">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
          <Header />
          
          {/* Main Content */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            {/* Left Column - Input and Response */}
            <div className="lg:col-span-8 space-y-8">
              <InputForm 
                onRecommendationsReceived={handleRecommendationsReceived}
                setLoading={setLoading}
              />
              
              <RecommendationDisplay 
                recommendations={recommendations} 
                loading={loading}
              />
              
              <BudgetTracker />
              
              <ItemRecommendations />
            </div>
            
            {/* Right Column - Calculator */}
            <div className="lg:col-span-4 space-y-8">
              <BudgetCalculator />
            </div>
          </div>
          
          <Footer />
        </div>
        
        <ToastContainer />
      </div>
    </BudgetProvider>
  );
}

export default App;