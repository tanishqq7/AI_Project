export interface GroceryItem {
  id: string;
  name: string;
  price: number;
  quantity: number;
  category: string;
  unit: string;
}

export interface Budget {
  total: number;
  spent: number;
  remaining: number;
}

export interface BudgetHistoryEntry {
  date: string;
  budgetAmount: number;
  spent: number;
  items: GroceryItem[];
}

export interface ApiResponse {
  success: boolean;
  message: string;
  data?: any;
  error?: string;
}

export interface RecommendationRequest {
  budget: number;
  items: GroceryItem[];
  preferences?: string[];
  dietaryRestrictions?: string[];
}

export interface RecommendationResponse {
  recommendedItems: GroceryItem[];
  nutritionSummary: {
    calories: number;
    protein: number;
    carbs: number;
    fats: number;
  };
  savingsOpportunities: {
    item: string;
    potentialSavings: number;
    alternativeItem: string;
  }[];
  analysis: string;
}