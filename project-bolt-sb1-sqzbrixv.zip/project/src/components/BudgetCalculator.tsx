import React, { useState, useEffect, useRef } from 'react';
import { Doughnut } from 'react-chartjs-2';
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from 'chart.js';
import { Calculator, Wallet, ShoppingCart, Tag, Weight } from 'lucide-react';
import { useBudget } from '../context/BudgetContext';
import { getGroceryItems } from '../services/api';
import { GroceryItem } from '../types';

ChartJS.register(ArcElement, Tooltip, Legend);

const BudgetCalculator: React.FC = () => {
  const { budget, setBudgetTotal, addGroceryItem } = useBudget();
  const [item, setItem] = useState('');
  const [price, setPrice] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [estimatedCost, setEstimatedCost] = useState(0);
  const [availableItems, setAvailableItems] = useState<GroceryItem[]>([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const suggestionsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Fetch available grocery items
    const fetchItems = async () => {
      const response = await getGroceryItems();
      if (response.success && response.data) {
        setAvailableItems(response.data);
      }
    };
    
    fetchItems();
  }, []);

  useEffect(() => {
    // Calculate estimated cost whenever price or quantity changes
    setEstimatedCost(price * quantity);
  }, [price, quantity]);

  useEffect(() => {
    // Close suggestions when clicking outside
    const handleClickOutside = (event: MouseEvent) => {
      if (suggestionsRef.current && !suggestionsRef.current.contains(event.target as Node)) {
        setShowSuggestions(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  // Handle budget update
  const handleBudgetUpdate = (value: number) => {
    setBudgetTotal(value);
  };

  // Handle adding item to budget
  const handleAddItem = () => {
    if (!item || price <= 0 || quantity <= 0) {
      return;
    }

    const newItem: GroceryItem = {
      id: Date.now().toString(),
      name: item,
      price,
      quantity,
      category: 'Other',
      unit: 'kg'
    };

    addGroceryItem(newItem);
    
    // Reset form
    setItem('');
    setPrice(0);
    setQuantity(1);
  };

  // Filter suggestions based on input
  const filteredSuggestions = availableItems.filter(i => 
    i.name.toLowerCase().includes(item.toLowerCase())
  );

  // Select an item from suggestions
  const selectItem = (selectedItem: GroceryItem) => {
    setItem(selectedItem.name);
    setPrice(selectedItem.price);
    setQuantity(selectedItem.quantity);
    setShowSuggestions(false);
  };

  // Chart data
  const chartData = {
    labels: ['Remaining', 'Spent'],
    datasets: [
      {
        data: [Math.max(0, budget.remaining), budget.spent],
        backgroundColor: ['#14b8a6', '#94a3b8'],
        borderColor: ['#0f766e', '#64748b'],
        borderWidth: 1,
      },
    ],
  };

  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    cutout: '70%',
    plugins: {
      legend: {
        position: 'bottom' as const,
        labels: {
          usePointStyle: true,
          padding: 20,
        },
      },
      tooltip: {
        callbacks: {
          label: function(context: any) {
            return `₹${context.raw.toFixed(2)}`;
          }
        }
      }
    },
  };

  return (
    <div className="bg-white rounded-2xl shadow-card border border-neutral-200 transition-all duration-300 hover:shadow-card-hover overflow-hidden sticky top-8">
      <div className="bg-gradient-to-r from-brand-700 to-brand-500 px-6 py-4">
        <h2 className="heading text-xl font-semibold text-white flex items-center">
          <Calculator className="mr-3" size={20} />
          Budget Calculator
        </h2>
      </div>
      <div className="p-6">
        <div className="space-y-5 mb-6">
          <div className="input-focus-effect">
            <label htmlFor="calcBudget" className="block text-neutral-700 text-sm font-medium mb-2 flex items-center">
              <Wallet className="text-brand-500 mr-2" size={16} />
              Total Budget (₹)
            </label>
            <div className="relative">
              <span className="absolute left-4 top-3.5 text-neutral-400">₹</span>
              <input 
                type="number" 
                id="calcBudget" 
                className="w-full pl-10 pr-4 py-3 rounded-xl border border-neutral-300 focus:outline-none focus:border-brand-400 focus:ring-2 focus:ring-brand-100 transition-all bg-neutral-50" 
                placeholder="Enter budget"
                value={budget.total || ''}
                onChange={(e) => handleBudgetUpdate(Number(e.target.value))}
              />
            </div>
          </div>
          
          <div className="input-focus-effect">
            <label htmlFor="calcItem" className="block text-neutral-700 text-sm font-medium mb-2 flex items-center">
              <ShoppingCart className="text-brand-500 mr-2" size={16} />
              Item Name
            </label>
            <div className="relative">
              <Tag className="absolute left-4 top-3.5 text-neutral-400" size={16} />
              <input 
                type="text" 
                id="calcItem" 
                className="w-full pl-10 pr-4 py-3 rounded-xl border border-neutral-300 focus:outline-none focus:border-brand-400 focus:ring-2 focus:ring-brand-100 transition-all bg-neutral-50" 
                placeholder="Item name"
                value={item}
                onChange={(e) => setItem(e.target.value)}
                onFocus={() => setShowSuggestions(true)}
              />
              
              {/* Item suggestions */}
              {showSuggestions && filteredSuggestions.length > 0 && (
                <div 
                  ref={suggestionsRef}
                  className="absolute z-10 w-full bg-white mt-1 rounded-xl shadow-lg border border-neutral-200 max-h-40 overflow-y-auto"
                >
                  {filteredSuggestions.map((suggestion) => (
                    <div
                      key={suggestion.id}
                      className="px-4 py-2 hover:bg-neutral-50 cursor-pointer flex justify-between"
                      onClick={() => selectItem(suggestion)}
                    >
                      <span>{suggestion.name}</span>
                      <span className="text-brand-600 font-medium">₹{suggestion.price}/kg</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
          
          <div className="input-focus-effect">
            <label htmlFor="calcPrice" className="block text-neutral-700 text-sm font-medium mb-2 flex items-center">
              <Tag className="text-brand-500 mr-2" size={16} />
              Price (₹/kg)
            </label>
            <div className="relative">
              <span className="absolute left-4 top-3.5 text-neutral-400">₹</span>
              <input 
                type="number" 
                id="calcPrice" 
                className="w-full pl-10 pr-4 py-3 rounded-xl border border-neutral-300 focus:outline-none focus:border-brand-400 focus:ring-2 focus:ring-brand-100 transition-all bg-neutral-50" 
                placeholder="Price per kg"
                value={price || ''}
                onChange={(e) => setPrice(Number(e.target.value))}
              />
            </div>
          </div>
          
          <div className="input-focus-effect">
            <label htmlFor="calcQuantity" className="block text-neutral-700 text-sm font-medium mb-2 flex items-center">
              <Weight className="text-brand-500 mr-2" size={16} />
              Quantity (kg)
            </label>
            <div className="relative">
              <span className="absolute left-4 top-3.5 text-neutral-400">kg</span>
              <input 
                type="number" 
                id="calcQuantity" 
                className="w-full pl-10 pr-4 py-3 rounded-xl border border-neutral-300 focus:outline-none focus:border-brand-400 focus:ring-2 focus:ring-brand-100 transition-all bg-neutral-50" 
                placeholder="Quantity in kg"
                value={quantity || ''}
                onChange={(e) => setQuantity(Number(e.target.value))}
                step="0.1"
                min="0"
              />
            </div>
          </div>
        </div>
        
        <button 
          className="w-full bg-gradient-to-r from-neutral-700 to-neutral-600 hover:from-neutral-800 hover:to-neutral-700 text-white font-medium py-3 px-6 rounded-xl transition duration-300 ease-in-out flex items-center justify-center mb-6"
          onClick={handleAddItem}
        >
          <ShoppingCart className="mr-2" size={16} />
          Add to Budget
        </button>
        
        {/* Results Section */}
        <div className="bg-neutral-50 rounded-xl border border-neutral-200 p-5">
          <div className="mb-4 h-48">
            <Doughnut data={chartData} options={chartOptions} />
          </div>
          
          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-neutral-600 flex items-center">
                <Tag className="text-brand-500 mr-2" size={16} />
                Estimated Cost:
              </span>
              <span className="font-medium text-neutral-800">₹{estimatedCost.toFixed(2)}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-neutral-600 flex items-center">
                <ShoppingCart className="text-brand-500 mr-2" size={16} />
                Total Spent:
              </span>
              <span className="font-medium text-neutral-800">₹{budget.spent.toFixed(2)}</span>
            </div>
            <div className="flex justify-between items-center pt-3 border-t border-neutral-200">
              <span className="text-neutral-700 font-medium flex items-center">
                <Wallet className="text-brand-500 mr-2" size={16} />
                Remaining Budget:
              </span>
              <span className={`font-semibold ${budget.remaining < 0 ? 'text-red-600' : budget.remaining === 0 ? 'text-yellow-600' : 'text-brand-600'}`}>
                ₹{budget.remaining.toFixed(2)}
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BudgetCalculator;