import React from 'react';
import { LineChart, BarChart3 } from 'lucide-react';

const Header: React.FC = () => {
  const currentDate = new Date().toLocaleDateString('en-IN', {
    day: 'numeric',
    month: 'short',
    year: 'numeric'
  });

  return (
    <header className="mb-10">
      <div className="flex flex-col md:flex-row justify-between items-center">
        <div className="flex items-center mb-4 md:mb-0">
          <div className="bg-gradient-to-r from-brand-600 to-brand-400 p-3 rounded-xl shadow-lg mr-4 flex items-center justify-center">
            <BarChart3 className="text-white" size={24} />
          </div>
          <div>
            <h1 className="heading text-3xl font-bold text-neutral-900 tracking-tight">
              Budget<span className="text-brand-600">Pro</span>
            </h1>
            <p className="text-neutral-500 text-sm">Enterprise Grocery Budget Optimization</p>
          </div>
        </div>
        <div className="flex items-center space-x-4">
          <div className="hidden md:flex items-center bg-white rounded-full px-4 py-1.5 shadow-sm border border-neutral-200">
            <span className="text-brand-600 mr-2">₹</span>
            <span className="text-neutral-700 font-medium">INR/kg</span>
          </div>
          <div className="bg-white rounded-full px-4 py-1.5 shadow-sm border border-neutral-200 flex items-center">
            <LineChart className="text-brand-600 mr-2" size={16} />
            <span className="text-neutral-700 font-medium">{currentDate}</span>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;