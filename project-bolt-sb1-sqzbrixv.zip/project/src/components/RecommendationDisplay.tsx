import React from 'react';
import ReactMarkdown from 'react-markdown';
import { Bot } from 'lucide-react';
import Skeleton from 'react-loading-skeleton';
import 'react-loading-skeleton/dist/skeleton.css';

interface RecommendationDisplayProps {
  recommendations: string;
  loading: boolean;
}

const RecommendationDisplay: React.FC<RecommendationDisplayProps> = ({ recommendations, loading }) => {
  const currentTime = new Date().toLocaleTimeString('en-IN', { 
    hour: '2-digit', 
    minute: '2-digit' 
  });

  return (
    <div className="bg-white rounded-2xl shadow-card border border-neutral-200 transition-all duration-300 hover:shadow-card-hover overflow-hidden">
      <div className="bg-gradient-to-r from-brand-700 to-brand-500 px-6 py-4 flex justify-between items-center">
        <h2 className="heading text-xl font-semibold text-white flex items-center">
          <Bot className="mr-3" size={20} />
          Budget Analysis
        </h2>
        <div className="text-white text-sm bg-white bg-opacity-20 px-3 py-1 rounded-full">
          <span className="mr-1">⚡</span>
          AI-Powered
        </div>
      </div>
      
      <div className="p-6 min-h-[300px]">
        {loading ? (
          <div className="flex flex-col items-center justify-center py-16">
            <div className="relative">
              <div className="w-16 h-16 border-4 border-neutral-200 border-t-brand-500 rounded-full animate-spin"></div>
              <div className="absolute top-0 left-0 w-16 h-16 flex items-center justify-center">
                <Calculator className="text-brand-500" size={24} />
              </div>
            </div>
            <span className="mt-6 text-neutral-600 font-medium">Analyzing your budget requirements...</span>
            <span className="mt-2 text-neutral-500 text-sm">This may take a moment</span>
          </div>
        ) : recommendations ? (
          <>
            <div className="flex items-center justify-between mb-6 pb-4 border-b border-neutral-200">
              <div className="flex items-center">
                <div className="bg-brand-100 p-2 rounded-lg text-brand-600 mr-3">
                  <Bot size={20} />
                </div>
                <div>
                  <h3 className="heading text-lg font-medium text-neutral-900">Budget Analysis</h3>
                  <p className="text-neutral-500 text-sm">AI-generated recommendations</p>
                </div>
              </div>
              <div className="text-xs bg-neutral-100 text-neutral-600 px-3 py-1 rounded-full">
                {currentTime}
              </div>
            </div>
            <div className="markdown-content">
              <ReactMarkdown>{recommendations}</ReactMarkdown>
            </div>
          </>
        ) : (
          <div className="flex flex-col items-center justify-center h-full py-16 text-center text-neutral-500">
            <Bot size={48} className="text-neutral-300 mb-4" />
            <p className="text-lg font-medium text-neutral-600 mb-2">Submit your request to get started</p>
            <p className="max-w-md mx-auto">
              Enter your grocery items and budget above to receive AI-powered recommendations tailored to your needs.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

// Import required at the top
import { Calculator } from 'lucide-react';

export default RecommendationDisplay;