import React from 'react';
import { BarChart3, Linkedin, Twitter, Facebook } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="mt-16 border-t border-neutral-200 pt-8 pb-10">
      <div className="flex flex-col md:flex-row justify-between items-center">
        <div className="flex items-center mb-4 md:mb-0">
          <div className="bg-gradient-to-r from-brand-600 to-brand-400 p-2 rounded-lg shadow-sm mr-3 flex items-center justify-center">
            <BarChart3 className="text-white" size={16} />
          </div>
          <span className="heading font-semibold text-neutral-700">BudgetPro</span>
        </div>
        <div className="text-neutral-500 text-sm">
          © {new Date().getFullYear()} Enterprise Grocery Budget Optimization | All rights reserved
        </div>
        <div className="flex space-x-4 mt-4 md:mt-0">
          <a href="#" className="text-neutral-400 hover:text-brand-500 transition-colors">
            <Linkedin size={18} />
          </a>
          <a href="#" className="text-neutral-400 hover:text-brand-500 transition-colors">
            <Twitter size={18} />
          </a>
          <a href="#" className="text-neutral-400 hover:text-brand-500 transition-colors">
            <Facebook size={18} />
          </a>
        </div>
      </div>
    </footer>
  );
};

export default Footer;