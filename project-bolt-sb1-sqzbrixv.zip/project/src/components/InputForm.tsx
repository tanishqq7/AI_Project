import React, { useState } from 'react';
import { List as ListUl, Calculator } from 'lucide-react';
import { getAIRecommendations } from '../services/api';
import { useBudget } from '../context/BudgetContext';

interface InputFormProps {
  onRecommendationsReceived: (recommendations: string) => void;
  setLoading: (loading: boolean) => void;
}

const InputForm: React.FC<InputFormProps> = ({ onRecommendationsReceived, setLoading }) => {
  const [userInput, setUserInput] = useState('');
  const { budget, groceryItems, setBudgetTotal } = useBudget();
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!userInput.trim()) {
      return;
    }
    
    setLoading(true);
    
    try {
      // Extract budget amount from input if provided
      const budgetMatch = userInput.match(/₹(\d+)/);
      if (budgetMatch) {
        const newBudget = parseFloat(budgetMatch[1]);
        if (!isNaN(newBudget)) {
          setBudgetTotal(newBudget);
        }
      }

      // Include current budget and items in the request for context
      const enhancedPrompt = `
Current Budget: ₹${budget.total}
Current Items: ${groceryItems.map(item => `${item.name} (${item.quantity}kg - ₹${item.price}/kg)`).join(', ')}
Spent so far: ₹${budget.spent}
Remaining budget: ₹${budget.remaining}

User request: ${userInput}

Provide grocery recommendations and budget analysis. Format with markdown headings, bullet points, and tables.
      `;
      
      const recommendations = await getAIRecommendations(enhancedPrompt);
      onRecommendationsReceived(recommendations);
    } catch (error) {
      console.error('Error getting recommendations:', error);
      onRecommendationsReceived('Sorry, we encountered an error while generating recommendations. Please try again later.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white rounded-2xl shadow-card border border-neutral-200 transition-all duration-300 hover:shadow-card-hover overflow-hidden">
      <div className="bg-gradient-to-r from-brand-700 to-brand-500 px-6 py-4">
        <h2 className="heading text-xl font-semibold text-white flex items-center">
          <ListUl className="mr-3" size={20} />
          Shopping Budget Planner
        </h2>
      </div>
      <div className="p-6">
        <p className="text-neutral-600 mb-6">
          Enter your grocery items (in kg) and budget (in INR) to receive AI-powered shopping suggestions optimized for your needs.
        </p>
        
        <form onSubmit={handleSubmit}>
          <div className="mb-6 input-focus-effect">
            <div className="relative">
              <ListUl className="absolute left-4 top-4 text-neutral-400" size={20} />
              <input
                type="text"
                className="w-full pl-12 pr-4 py-4 rounded-xl border border-neutral-300 focus:outline-none focus:border-brand-400 focus:ring-2 focus:ring-brand-100 transition-all bg-neutral-50"
                placeholder="Enter items (kg) and budget (INR) (e.g., Apples 1kg, Milk 2kg, ₹500)"
                value={userInput}
                onChange={(e) => setUserInput(e.target.value)}
              />
            </div>
          </div>
          
          <button
            type="submit"
            className="w-full bg-gradient-to-r from-brand-600 to-brand-500 hover:from-brand-700 hover:to-brand-600 text-white font-medium py-4 px-6 rounded-xl transition duration-300 ease-in-out flex items-center justify-center pulse-on-hover"
          >
            <Calculator className="mr-2" size={20} />
            Generate Budget Plan
          </button>
        </form>
      </div>
    </div>
  );
};

export default InputForm;