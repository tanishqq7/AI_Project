import React, { useState } from 'react';
import { History, ShoppingCart, Trash2, Download } from 'lucide-react';
import { useBudget } from '../context/BudgetContext';
import { GroceryItem } from '../types';

const BudgetTracker: React.FC = () => {
  const { groceryItems, budget, removeGroceryItem, updateGroceryItem, saveBudget } = useBudget();
  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);

  // Handle saving the current budget
  const handleSave = async () => {
    setIsSaving(true);
    try {
      const success = await saveBudget();
      setSaveSuccess(success);
      setTimeout(() => setSaveSuccess(false), 3000);
    } catch (error) {
      console.error('Error saving budget:', error);
    } finally {
      setIsSaving(false);
    }
  };

  // Handle quantity change
  const handleQuantityChange = (item: GroceryItem, newQuantity: number) => {
    if (newQuantity >= 0) {
      updateGroceryItem(item.id, { quantity: newQuantity });
    }
  };

  // Export budget data as CSV
  const exportCSV = () => {
    const headers = ['Item', 'Price (₹/kg)', 'Quantity (kg)', 'Total (₹)'];
    
    const rows = groceryItems.map(item => [
      item.name,
      item.price.toFixed(2),
      item.quantity.toFixed(2),
      (item.price * item.quantity).toFixed(2)
    ]);
    
    // Add summary row
    rows.push([
      'TOTAL',
      '',
      '',
      budget.spent.toFixed(2)
    ]);
    
    rows.push([
      'BUDGET',
      '',
      '',
      budget.total.toFixed(2)
    ]);
    
    rows.push([
      'REMAINING',
      '',
      '',
      budget.remaining.toFixed(2)
    ]);
    
    // Convert to CSV
    const csvContent = [
      headers.join(','),
      ...rows.map(row => row.join(','))
    ].join('\n');
    
    // Create download link
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    
    link.setAttribute('href', url);
    link.setAttribute('download', `budget_${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = 'hidden';
    
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="bg-white rounded-2xl shadow-card border border-neutral-200 transition-all duration-300 hover:shadow-card-hover overflow-hidden">
      <div className="bg-gradient-to-r from-brand-700 to-brand-500 px-6 py-4 flex justify-between items-center">
        <h2 className="heading text-xl font-semibold text-white flex items-center">
          <History className="mr-3" size={20} />
          Budget Tracker
        </h2>
        <div className="flex space-x-2">
          <button 
            onClick={exportCSV}
            className="bg-white bg-opacity-20 hover:bg-opacity-30 text-white p-1.5 rounded-lg transition-all duration-300"
            title="Export as CSV"
          >
            <Download size={18} />
          </button>
          <button 
            onClick={handleSave}
            disabled={isSaving || groceryItems.length === 0}
            className={`bg-white text-brand-700 px-3 py-1 rounded-lg text-sm font-medium transition-all duration-300 ${
              isSaving || groceryItems.length === 0 ? 'opacity-50 cursor-not-allowed' : 'hover:bg-opacity-90'
            }`}
          >
            {isSaving ? 'Saving...' : saveSuccess ? 'Saved!' : 'Save'}
          </button>
        </div>
      </div>

      <div className="p-6">
        {groceryItems.length > 0 ? (
          <>
            <div className="bg-neutral-50 rounded-xl p-4 mb-6 border border-neutral-200">
              <div className="flex justify-between items-center mb-3">
                <div className="text-neutral-700 font-medium">Budget Summary</div>
                <div className="text-neutral-500 text-sm">{groceryItems.length} items</div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-white rounded-lg p-3 border border-neutral-200">
                  <div className="text-sm text-neutral-500">Total Budget</div>
                  <div className="text-xl font-semibold text-neutral-800">₹{budget.total.toFixed(2)}</div>
                </div>
                <div className="bg-white rounded-lg p-3 border border-neutral-200">
                  <div className="text-sm text-neutral-500">Spent</div>
                  <div className="text-xl font-semibold text-neutral-800">₹{budget.spent.toFixed(2)}</div>
                </div>
                <div className="bg-white rounded-lg p-3 border border-neutral-200">
                  <div className="text-sm text-neutral-500">Remaining</div>
                  <div className={`text-xl font-semibold ${budget.remaining < 0 ? 'text-red-600' : budget.remaining === 0 ? 'text-yellow-600' : 'text-brand-600'}`}>
                    ₹{budget.remaining.toFixed(2)}
                  </div>
                </div>
                <div className="bg-white rounded-lg p-3 border border-neutral-200">
                  <div className="text-sm text-neutral-500">Budget Used</div>
                  <div className="text-xl font-semibold text-neutral-800">
                    {budget.total > 0 ? `${Math.min(100, (budget.spent / budget.total * 100)).toFixed(1)}%` : '0%'}
                  </div>
                </div>
              </div>
            </div>

            <div className="overflow-hidden rounded-xl border border-neutral-200">
              <table className="min-w-full divide-y divide-neutral-200">
                <thead className="bg-neutral-50">
                  <tr>
                    <th scope="col" className="px-4 py-3.5 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                      Item
                    </th>
                    <th scope="col" className="px-4 py-3.5 text-right text-xs font-medium text-neutral-500 uppercase tracking-wider">
                      Price/kg
                    </th>
                    <th scope="col" className="px-4 py-3.5 text-right text-xs font-medium text-neutral-500 uppercase tracking-wider">
                      Quantity
                    </th>
                    <th scope="col" className="px-4 py-3.5 text-right text-xs font-medium text-neutral-500 uppercase tracking-wider">
                      Total
                    </th>
                    <th scope="col" className="px-4 py-3.5 text-right text-xs font-medium text-neutral-500 uppercase tracking-wider">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-neutral-100">
                  {groceryItems.map((item) => (
                    <tr key={item.id} className="hover:bg-neutral-50 transition-colors">
                      <td className="px-4 py-3 whitespace-nowrap text-sm font-medium text-neutral-800">
                        {item.name}
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap text-sm text-neutral-600 text-right">
                        ₹{item.price.toFixed(2)}
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap text-sm text-neutral-600 text-right">
                        <div className="flex items-center justify-end">
                          <button 
                            className="text-neutral-500 hover:text-neutral-700"
                            onClick={() => handleQuantityChange(item, Math.max(0, item.quantity - 0.5))}
                          >
                            -
                          </button>
                          <span className="mx-2 w-12 text-center">{item.quantity.toFixed(1)}</span>
                          <button 
                            className="text-neutral-500 hover:text-neutral-700"
                            onClick={() => handleQuantityChange(item, item.quantity + 0.5)}
                          >
                            +
                          </button>
                        </div>
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap text-sm font-medium text-neutral-800 text-right">
                        ₹{(item.price * item.quantity).toFixed(2)}
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap text-sm text-neutral-600 text-right">
                        <button 
                          className="text-neutral-400 hover:text-red-500 transition-colors"
                          onClick={() => removeGroceryItem(item.id)}
                        >
                          <Trash2 size={16} />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </>
        ) : (
          <div className="flex flex-col items-center justify-center py-10 text-center">
            <div className="bg-neutral-100 p-4 rounded-full mb-4">
              <ShoppingCart className="text-neutral-400" size={32} />
            </div>
            <h3 className="heading text-lg font-medium text-neutral-700 mb-2">No items in your budget yet</h3>
            <p className="text-neutral-500 max-w-md">
              Use the Budget Calculator to add grocery items and track your spending against your budget.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default BudgetTracker;