import React, { useState, useEffect } from 'react';
import { getRecommendations } from '../services/api';
import { useBudget } from '../context/BudgetContext';
import { GroceryItem } from '../types';
import { Check, ShoppingBag, PlusCircle } from 'lucide-react';

const ItemRecommendations: React.FC = () => {
  const { budget, groceryItems, addGroceryItem } = useBudget();
  const [recommendations, setRecommendations] = useState<GroceryItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [analysis, setAnalysis] = useState('');
  const [addedItems, setAddedItems] = useState<Set<string>>(new Set());

  useEffect(() => {
    // Get recommendations when budget or items change
    if (budget.total > 0) {
      fetchRecommendations();
    }
  }, [budget.total, groceryItems.length]);

  const fetchRecommendations = async () => {
    setLoading(true);
    try {
      const response = await getRecommendations({
        budget: budget.total,
        items: groceryItems,
      });

      if (response.success && response.data) {
        setRecommendations(response.data.recommendedItems || []);
        setAnalysis(response.data.analysis || '');
      }
    } catch (error) {
      console.error('Error fetching recommendations:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleAddItem = (item: GroceryItem) => {
    addGroceryItem(item);
    setAddedItems(prev => new Set(prev).add(item.id));
  };

  return (
    <div className="bg-white rounded-2xl shadow-card border border-neutral-200 transition-all duration-300 hover:shadow-card-hover overflow-hidden">
      <div className="bg-gradient-to-r from-brand-700 to-brand-500 px-6 py-4">
        <h2 className="heading text-xl font-semibold text-white flex items-center">
          <ShoppingBag className="mr-3" size={20} />
          Recommended Items
        </h2>
      </div>

      <div className="p-6">
        {loading ? (
          <div className="flex justify-center items-center py-10">
            <div className="w-10 h-10 border-4 border-neutral-200 border-t-brand-500 rounded-full animate-spin"></div>
          </div>
        ) : recommendations.length > 0 ? (
          <>
            <div className="bg-neutral-50 rounded-xl p-4 mb-6 border border-neutral-200">
              <p className="text-neutral-700">{analysis}</p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {recommendations.map((item) => (
                <div 
                  key={item.id}
                  className="border border-neutral-200 rounded-xl p-4 hover:border-brand-300 transition-colors"
                >
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="font-medium text-neutral-800">{item.name}</h3>
                    <span className="text-brand-600 font-medium">₹{item.price}</span>
                  </div>
                  <div className="text-sm text-neutral-500 mb-3">
                    {item.quantity} {item.unit}
                  </div>
                  <button
                    onClick={() => handleAddItem(item)}
                    disabled={addedItems.has(item.id)}
                    className={`w-full py-2 rounded-lg flex items-center justify-center text-sm font-medium transition-all ${
                      addedItems.has(item.id)
                        ? 'bg-neutral-100 text-neutral-500 cursor-not-allowed'
                        : 'bg-brand-50 text-brand-600 hover:bg-brand-100'
                    }`}
                  >
                    {addedItems.has(item.id) ? (
                      <>
                        <Check size={16} className="mr-1" />
                        Added to Budget
                      </>
                    ) : (
                      <>
                        <PlusCircle size={16} className="mr-1" />
                        Add to Budget
                      </>
                    )}
                  </button>
                </div>
              ))}
            </div>
          </>
        ) : (
          <div className="flex flex-col items-center justify-center py-10 text-center">
            <div className="bg-neutral-100 p-4 rounded-full mb-4">
              <ShoppingBag className="text-neutral-400" size={32} />
            </div>
            <h3 className="heading text-lg font-medium text-neutral-700 mb-2">No recommendations yet</h3>
            <p className="text-neutral-500 max-w-md">
              {budget.total > 0 
                ? "We'll provide smart grocery recommendations based on your budget and current items."
                : "Set a budget to receive personalized grocery recommendations."}
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default ItemRecommendations;