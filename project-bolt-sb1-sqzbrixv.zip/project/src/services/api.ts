import axios from 'axios';
import { GroceryItem, RecommendationRequest, RecommendationResponse, ApiResponse } from '../types';

const API_URL = import.meta.env.VITE_API_URL || 'https://api.budgetpro.example.com';
const OPENROUTER_API_KEY = import.meta.env.VITE_OPENROUTER_API_KEY || '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';

const api = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Mock data for grocery items
const mockGroceryDatabase: GroceryItem[] = [
  { id: '1', name: 'Rice', price: 60, quantity: 1, category: 'Grains', unit: 'kg' },
  { id: '2', name: 'Wheat Flour', price: 40, quantity: 1, category: 'Grains', unit: 'kg' },
  { id: '3', name: 'Toor Dal', price: 120, quantity: 1, category: 'Pulses', unit: 'kg' },
  { id: '4', name: 'Moong Dal', price: 110, quantity: 1, category: 'Pulses', unit: 'kg' },
  { id: '5', name: 'Chana Dal', price: 95, quantity: 1, category: 'Pulses', unit: 'kg' },
  { id: '6', name: 'Potatoes', price: 30, quantity: 1, category: 'Vegetables', unit: 'kg' },
  { id: '7', name: 'Onions', price: 40, quantity: 1, category: 'Vegetables', unit: 'kg' },
  { id: '8', name: 'Tomatoes', price: 50, quantity: 1, category: 'Vegetables', unit: 'kg' },
  { id: '9', name: 'Milk', price: 65, quantity: 1, category: 'Dairy', unit: 'liter' },
  { id: '10', name: 'Eggs', price: 7, quantity: 12, category: 'Protein', unit: 'dozen' },
  { id: '11', name: 'Chicken', price: 180, quantity: 1, category: 'Protein', unit: 'kg' },
  { id: '12', name: 'Apples', price: 150, quantity: 1, category: 'Fruits', unit: 'kg' },
  { id: '13', name: 'Bananas', price: 60, quantity: 1, category: 'Fruits', unit: 'dozen' },
  { id: '14', name: 'Sugar', price: 45, quantity: 1, category: 'Essentials', unit: 'kg' },
  { id: '15', name: 'Salt', price: 20, quantity: 1, category: 'Essentials', unit: 'kg' },
  { id: '16', name: 'Cooking Oil', price: 140, quantity: 1, category: 'Essentials', unit: 'liter' },
  { id: '17', name: 'Tea', price: 240, quantity: 0.5, category: 'Beverages', unit: 'kg' },
  { id: '18', name: 'Coffee', price: 350, quantity: 0.25, category: 'Beverages', unit: 'kg' },
  { id: '19', name: 'Biscuits', price: 30, quantity: 1, category: 'Snacks', unit: 'pack' },
  { id: '20', name: 'Bread', price: 40, quantity: 1, category: 'Bakery', unit: 'loaf' }
];

// Get all grocery items
export const getGroceryItems = async (): Promise<ApiResponse> => {
  try {
    // In a real app, this would be an API call
    // return await api.get('/items');
    
    return {
      success: true,
      message: 'Grocery items fetched successfully',
      data: mockGroceryDatabase
    };
  } catch (error) {
    return {
      success: false,
      message: 'Failed to fetch grocery items',
      error: error instanceof Error ? error.message : 'Unknown error'
    };
  }
};

// Get grocery item recommendations based on budget
export const getRecommendations = async (request: RecommendationRequest): Promise<ApiResponse> => {
  try {
    // This would be an API call in a real application
    // return await api.post('/recommendations', request);
    
    // For now, we'll create a mock recommendation engine
    const { budget, items } = request;
    const currentCost = items.reduce((acc, item) => acc + (item.price * item.quantity), 0);
    const remainingBudget = budget - currentCost;
    
    // Filter items not already in the cart and sort by value (price/quantity)
    const existingItemIds = items.map(item => item.id);
    const availableItems = mockGroceryDatabase
      .filter(item => !existingItemIds.includes(item.id))
      .sort((a, b) => a.price / a.quantity - b.price / b.quantity);
    
    // Select recommended items based on remaining budget
    const recommendedItems: GroceryItem[] = [];
    let allocatedBudget = 0;
    
    for (const item of availableItems) {
      if (allocatedBudget + item.price <= remainingBudget) {
        recommendedItems.push(item);
        allocatedBudget += item.price;
      }
    }
    
    const mockResponse: RecommendationResponse = {
      recommendedItems,
      nutritionSummary: {
        calories: 2000,
        protein: 60,
        carbs: 250,
        fats: 70
      },
      savingsOpportunities: [
        {
          item: 'Branded Rice',
          potentialSavings: 20,
          alternativeItem: 'Local Rice'
        },
        {
          item: 'Imported Apples',
          potentialSavings: 50,
          alternativeItem: 'Local Seasonal Fruits'
        }
      ],
      analysis: `Based on your current selections and budget of ₹${budget}, we recommend adding ${recommendedItems.length} more items to maximize nutrition and value. You'll still have ₹${(remainingBudget - allocatedBudget).toFixed(2)} remaining in your budget.`
    };
    
    return {
      success: true,
      message: 'Recommendations generated successfully',
      data: mockResponse
    };
  } catch (error) {
    return {
      success: false,
      message: 'Failed to generate recommendations',
      error: error instanceof Error ? error.message : 'Unknown error'
    };
  }
};

// Get AI grocery recommendations using OpenRouter API
export const getAIRecommendations = async (userInput: string): Promise<string> => {
  // Check if API key is available and valid
  if (!OPENROUTER_API_KEY || OPENROUTER_API_KEY === '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') {
    console.warn('OpenRouter API key is missing or using default value. Falling back to mock response.');
    return getMockAIResponse();
  }

  try {
    const response = await axios.post(
      'https://openrouter.ai/api/v1/chat/completions',
      {
        model: 'google/gemini-pro',
        messages: [
          {
            role: 'system',
            content: 'You are an AI Grocery Budget Planner. Your purpose is to help users maximize their grocery shopping budget in Indian Rupees (INR) and kilograms (kg). You can provide optimized shopping suggestions and use a budget calculator. Format your response in markdown for better readability. Include a budget breakdown, recommended items with prices, and potential savings opportunities.'
          },
          {
            role: 'user',
            content: userInput
          }
        ]
      },
      {
        headers: {
          Authorization: `Bearer ${OPENROUTER_API_KEY}`,
          'HTTP-Referer': 'https://budgetpro.app',
          'X-Title': 'BudgetPro Grocery Planner',
          'Content-Type': 'application/json'
        }
      }
    );

    return response.data.choices[0]?.message?.content || getMockAIResponse();
  } catch (error) {
    if (axios.isAxiosError(error) && error.response?.status === 401) {
      console.warn('OpenRouter API authentication failed. Please check your API key. Falling back to mock response.');
    } else {
      console.error('AI recommendation error:', error);
    }
    return getMockAIResponse();
  }
};

// Helper function to get mock AI response
function getMockAIResponse(): string {
  return `# Smart Budget Grocery Recommendations

## Budget Analysis
Based on your input, I've prepared a customized grocery plan to maximize your budget.

### Recommended Items

| Item | Price (₹) | Quantity | Total |
|------|-----------|----------|-------|
| Rice | 60 | 5 kg | ₹300 |
| Wheat Flour | 40 | 2 kg | ₹80 |
| Toor Dal | 120 | 1 kg | ₹120 |
| Potatoes | 30 | 2 kg | ₹60 |
| Onions | 40 | 2 kg | ₹80 |
| Cooking Oil | 140 | 1 liter | ₹140 |
| Eggs | 7 | 2 dozen | ₹14 |

### Potential Savings Opportunities
- Choose local rice brands instead of premium brands (Save ₹20-30/kg)
- Buy seasonal vegetables from local markets (Save up to ₹50/week)
- Consider buying pulses in bulk (Save approximately 10-15%)

### Tips for Stretching Your Budget
1. Plan meals around staples like rice and dal
2. Buy vegetables that stay fresh longer (like potatoes, onions)
3. Consider adding affordable protein sources like eggs or tofu

I hope these suggestions help you make the most of your grocery budget!`;
}

// Save budget history
export const saveBudgetHistory = async (data: any): Promise<ApiResponse> => {
  try {
    // In a real app, this would be an API call
    // return await api.post('/budget/history', data);
    
    // For mock purposes, just return success
    return {
      success: true,
      message: 'Budget history saved successfully',
      data: { id: Date.now().toString() }
    };
  } catch (error) {
    return {
      success: false,
      message: 'Failed to save budget history',
      error: error instanceof Error ? error.message : 'Unknown error'
    };
  }
};

export default {
  getGroceryItems,
  getRecommendations,
  getAIRecommendations,
  saveBudgetHistory
};