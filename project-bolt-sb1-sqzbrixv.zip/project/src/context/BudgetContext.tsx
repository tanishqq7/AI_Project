import { createContext, useState, useContext, ReactNode, useEffect } from 'react';
import { Budget, GroceryItem, BudgetHistoryEntry } from '../types';
import { saveBudgetHistory } from '../services/api';

interface BudgetContextProps {
  budget: Budget;
  groceryItems: GroceryItem[];
  budgetHistory: BudgetHistoryEntry[];
  setBudgetTotal: (amount: number) => void;
  addGroceryItem: (item: GroceryItem) => void;
  updateGroceryItem: (id: string, updates: Partial<GroceryItem>) => void;
  removeGroceryItem: (id: string) => void;
  calculateTotals: () => void;
  clearItems: () => void;
  saveBudget: () => Promise<boolean>;
}

const BudgetContext = createContext<BudgetContextProps | undefined>(undefined);

export const BudgetProvider = ({ children }: { children: ReactNode }) => {
  const [budget, setBudget] = useState<Budget>({
    total: 0,
    spent: 0,
    remaining: 0
  });
  
  const [groceryItems, setGroceryItems] = useState<GroceryItem[]>([]);
  const [budgetHistory, setBudgetHistory] = useState<BudgetHistoryEntry[]>([]);

  // Load data from localStorage on initial render
  useEffect(() => {
    const savedItems = localStorage.getItem('groceryItems');
    const savedBudget = localStorage.getItem('budget');
    const savedHistory = localStorage.getItem('budgetHistory');
    
    if (savedItems) {
      setGroceryItems(JSON.parse(savedItems));
    }
    
    if (savedBudget) {
      setBudget(JSON.parse(savedBudget));
    }
    
    if (savedHistory) {
      setBudgetHistory(JSON.parse(savedHistory));
    }
  }, []);

  // Save data to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem('groceryItems', JSON.stringify(groceryItems));
    localStorage.setItem('budget', JSON.stringify(budget));
    localStorage.setItem('budgetHistory', JSON.stringify(budgetHistory));
  }, [groceryItems, budget, budgetHistory]);

  const setBudgetTotal = (amount: number) => {
    setBudget(prev => ({
      ...prev,
      total: amount,
      remaining: amount - prev.spent
    }));
    calculateTotals();
  };

  const addGroceryItem = (item: GroceryItem) => {
    setGroceryItems(prev => [...prev, item]);
    calculateTotals();
  };

  const updateGroceryItem = (id: string, updates: Partial<GroceryItem>) => {
    setGroceryItems(prev => 
      prev.map(item => 
        item.id === id ? { ...item, ...updates } : item
      )
    );
    calculateTotals();
  };

  const removeGroceryItem = (id: string) => {
    setGroceryItems(prev => prev.filter(item => item.id !== id));
    calculateTotals();
  };

  const calculateTotals = () => {
    const totalSpent = groceryItems.reduce(
      (acc, item) => acc + item.price * item.quantity,
      0
    );
    
    setBudget(prev => ({
      ...prev,
      spent: totalSpent,
      remaining: prev.total - totalSpent
    }));
  };

  const clearItems = () => {
    setGroceryItems([]);
    setBudget(prev => ({
      ...prev,
      spent: 0,
      remaining: prev.total
    }));
  };

  const saveBudget = async (): Promise<boolean> => {
    const budgetEntry: BudgetHistoryEntry = {
      date: new Date().toISOString(),
      budgetAmount: budget.total,
      spent: budget.spent,
      items: [...groceryItems]
    };
    
    try {
      const response = await saveBudgetHistory(budgetEntry);
      
      if (response.success) {
        setBudgetHistory(prev => [...prev, budgetEntry]);
        return true;
      }
      return false;
    } catch (error) {
      console.error('Error saving budget:', error);
      return false;
    }
  };

  return (
    <BudgetContext.Provider
      value={{
        budget,
        groceryItems,
        budgetHistory,
        setBudgetTotal,
        addGroceryItem,
        updateGroceryItem,
        removeGroceryItem,
        calculateTotals,
        clearItems,
        saveBudget
      }}
    >
      {children}
    </BudgetContext.Provider>
  );
};

export const useBudget = () => {
  const context = useContext(BudgetContext);
  if (context === undefined) {
    throw new Error('useBudget must be used within a BudgetProvider');
  }
  return context;
};